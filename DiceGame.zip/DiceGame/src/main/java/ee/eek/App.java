package ee.eek;

import java.util.Random;
import java.util.Scanner;

public final class App {
    private App() {
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean yes;

        do {
            yes = false;
            System.out.println("Enter the number of dice: ");
            int n = sc.nextInt();
            Random rand = new Random();
            System.out.println("The values on dice are: ");
            for (int i = 0; i < n; i++) {
                System.out.println(rand.nextInt(6) + 1);
            }
            System.out.println("Continue: y/n");
            sc.nextLine();
            String a = sc.nextLine();
            if ("y".equalsIgnoreCase(a)) {
                yes = true;
            }
        } while (yes);
        sc.close();

    }
}
