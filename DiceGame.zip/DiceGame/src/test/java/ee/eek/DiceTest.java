package ee.eek;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class DiceTest {

    @Test
    void main() {
        Assertions.assertThat(2 + 2).isEqualTo(4);
    }
}